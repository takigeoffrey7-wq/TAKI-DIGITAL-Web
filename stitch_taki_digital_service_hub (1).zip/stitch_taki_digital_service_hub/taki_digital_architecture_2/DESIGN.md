---
name: Taki Digital Architecture
colors:
  surface: '#051424'
  surface-dim: '#051424'
  surface-bright: '#2c3a4c'
  surface-container-lowest: '#010f1f'
  surface-container-low: '#0d1c2d'
  surface-container: '#122131'
  surface-container-high: '#1c2b3c'
  surface-container-highest: '#273647'
  on-surface: '#d4e4fa'
  on-surface-variant: '#c6c6cd'
  inverse-surface: '#d4e4fa'
  inverse-on-surface: '#233143'
  outline: '#909097'
  outline-variant: '#45464d'
  surface-tint: '#bec6e0'
  primary: '#bec6e0'
  on-primary: '#283044'
  primary-container: '#0f172a'
  on-primary-container: '#798098'
  inverse-primary: '#565e74'
  secondary: '#44e2cd'
  on-secondary: '#003731'
  secondary-container: '#03c6b2'
  on-secondary-container: '#004d44'
  tertiary: '#b9c7e0'
  on-tertiary: '#233144'
  tertiary-container: '#09182a'
  on-tertiary-container: '#738298'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#62fae3'
  secondary-fixed-dim: '#3cddc7'
  on-secondary-fixed: '#00201c'
  on-secondary-fixed-variant: '#005047'
  tertiary-fixed: '#d5e3fd'
  tertiary-fixed-dim: '#b9c7e0'
  on-tertiary-fixed: '#0d1c2f'
  on-tertiary-fixed-variant: '#3a485c'
  background: '#051424'
  on-background: '#d4e4fa'
  surface-variant: '#273647'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-lg:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  code-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  sidebar-width: 280px
  container-max-width: 1600px
  gutter-lg: 32px
  margin-edge: 40px
  unit-base: 8px
---

## Brand & Style
This design system embodies the "Digital Hub" aesthetic, tailored for professional high-density desktop environments. The personality is authoritative, precise, and systematic. It utilizes a refined **Corporate Modern** style with subtle **Minimalist** influences to ensure focus remains on complex data and architectural service workflows. 

The visual language communicates reliability and structural integrity through a disciplined grid, deep tonal backgrounds, and sharp accents. The target audience includes architects, project managers, and technical consultants who require a sophisticated, low-fatigue environment for long-duration work sessions.

## Colors
The palette is anchored by a deep navy primary (`#0f172a`), serving as the foundational canvas for the entire application to reduce eye strain. Professional teal (`#2dd4bf`) is used exclusively for primary actions, success states, and active indicators, providing a high-contrast focal point against the dark background. 

Secondary surfaces and borders utilize a mid-tone slate (`#334155`) to create structural hierarchy without breaking the dark-mode immersion. Typography and iconography primarily use neutral slates to manage information density through varying levels of luminance.

## Typography
The typographic system utilizes a tri-font pairing to distinguish between intent and function. **Hanken Grotesk** provides a sharp, contemporary feel for headlines and page titles. **Inter** is the workhorse for body copy and data tables, chosen for its exceptional legibility at standard sizes. **Geist** is reserved for labels, metadata, and technical strings, leaning into its monospaced-adjacent metrics to provide a precise, "engineered" look.

For this desktop-first system, scale is generous. Titles use tighter letter-spacing for a grounded appearance, while small labels use increased tracking to ensure readability against dark backgrounds.

## Layout & Spacing
The layout employs a **fixed-sidebar, fluid-content** model. The sidebar (280px) remains docked to the left, housing the primary navigation. The main content area uses a 12-column fluid grid for the service directory, allowing for multi-column card layouts that scale with high-resolution monitors.

Spacing follows an 8px rhythmic scale. Page margins are set to 40px to provide breathing room for professional workflows. In the service directory, gutters are increased to 32px to maintain clear separation between dense architectural project cards.

## Elevation & Depth
Depth is expressed through **Tonal Layers** rather than heavy shadows. In this dark UI, higher elevation is communicated by lightening the surface color. 

- **Level 0 (Background):** `#0f172a` (The deepest layer).
- **Level 1 (Cards/Sidebar):** `#1e293b` (Raised surfaces).
- **Level 2 (Modals/Popovers):** `#334155` (The highest layer).

Borders are used as the primary structural tool. Use 1px solid strokes in `#1e293b` or `#334155` to define boundaries. Subtle ambient shadows (0px 4px 20px rgba(0,0,0,0.4)) are reserved strictly for floating elements like dropdown menus and modals to ensure they sit clearly above the layout.

## Shapes
This design system uses a **Soft** shape language to balance the "technical" feel of the typography with an approachable interface. Standard components like buttons and input fields use a 4px (0.25rem) radius. Large containers and dashboard cards use an 8px (0.5rem) radius to define major content blocks. This subtle rounding maintains a professional, grid-aligned aesthetic without feeling overly organic or "bubbly."

## Components

### Buttons & Inputs
- **Primary Action:** Teal background (`#2dd4bf`) with navy text (`#0f172a`). High-contrast, no shadow, 4px radius.
- **Ghost Input:** Transparent background with a 1px slate border. On focus, the border transitions to teal with a subtle glow effect.

### Navigation Sidebar
- **Active State:** A vertical teal bar (4px wide) on the left edge of the navigation item, with a subtle `#1e293b` background tint for the entire row.
- **Icons:** Use linear, 20px icons with a 1.5px stroke weight to match the precision of the typography.

### Service Directory Cards
- **Structure:** 1px slate border, 8px radius. Header area uses Hanken Grotesk for the service name.
- **Metadata:** Use Geist (label-sm) for technical specs or project counts, presented in a "tag" format with low-contrast slate backgrounds.

### Data Tables
- **Header:** Sticky headers with a solid `#1e293b` background. 
- **Rows:** Subtle 1px bottom border only. No zebra striping; use a teal highlight on row hover to maintain a clean aesthetic.

### Status Indicators
- Use small, filled circular dots next to labels. Teal for "Active/Healthy", Slate for "Draft/Inactive", and Amber for "Action Required".