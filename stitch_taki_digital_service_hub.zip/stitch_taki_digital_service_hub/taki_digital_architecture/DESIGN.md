---
name: Taki Digital Architecture
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45464d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#006a61'
  on-secondary: '#ffffff'
  secondary-container: '#86f2e4'
  on-secondary-container: '#006f66'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#0b1c30'
  on-tertiary-container: '#75859d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#89f5e7'
  secondary-fixed-dim: '#6bd8cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#005049'
  tertiary-fixed: '#d3e4fe'
  tertiary-fixed-dim: '#b7c8e1'
  on-tertiary-fixed: '#0b1c30'
  on-tertiary-fixed-variant: '#38485d'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 48px
  container-max: 1280px
  gutter: 24px
---

## Brand & Style

The design system is engineered to project **efficiency, reliability, and technical precision**. As a multi-service digital agency hub, the interface adopts a "Super-App" philosophy—organizing complex, diverse service offerings into a cohesive, navigable ecosystem.

The aesthetic leans into **Corporate Modernism** with a focus on high information density managed through generous whitespace and rigid structural alignment. The emotional response should be one of "effortless utility"; users should feel that the platform is technologically savvy and hyper-organized. Visual flourishes are secondary to clarity, using subtle tonal shifts rather than decorative elements to guide the user's journey.

## Colors

The color palette is anchored by **Deep Slate Blue**, providing a foundation of authority and professional trust. This is contrasted against a **Crisp White** background to maintain a "digital-first" feel.

- **Primary (#0F172A):** Used for navigation, headers, and primary actions to establish a strong brand presence.
- **Secondary/Accent (#0D9488):** A professional Teal used for success states, active indicators, and secondary call-to-actions, providing a modern tech-forward spark.
- **Tertiary (#64748B):** A muted Slate used for secondary text and icons, ensuring hierarchy without clutter.
- **Surface:** The background utilizes a very light grey-blue tint (#F8FAFC) to reduce eye strain compared to pure white, while keeping the interface feeling airy.

## Typography

This design system utilizes **Inter** as its primary typeface to ensure maximum legibility and a systematic, utilitarian appearance across all digital touchpoints. 

For technical details, status codes, or metadata, **JetBrains Mono** is introduced as a secondary functional font. This adds a "developer-friendly" and precise character to the service-oriented data. 

**Hierarchy Rules:**
- Use negative letter-spacing on larger display titles to keep the "Super-App" feel compact and modern.
- All body text should maintain a minimum of 1.5x line height for optimal readability during long-form service descriptions.
- Labels are always uppercase when using the monospaced font to differentiate them from interactive body elements.

## Layout & Spacing

The layout follows a **Rigid 8pt Grid System** to ensure mathematical harmony. 

- **Desktop:** A 12-column fluid grid with 24px gutters. Content is housed in a max-width container of 1280px to prevent excessive line lengths on ultra-wide monitors.
- **Tablet:** 8-column grid with 16px gutters.
- **Mobile:** 4-column grid with 16px margins. 

The spacing rhythm is intentional: use `xl` (48px) to separate major service blocks, and `md` (16px) for internal card padding. This high-contrast spacing helps users mentally categorize different service offerings quickly.

## Elevation & Depth

To maintain a professional and clean look, this design system avoids heavy shadows. Depth is communicated through **Tonal Layering** and **Subtle Outlines**.

- **Level 0 (Base):** Background surface (#F8FAFC).
- **Level 1 (Cards/Containers):** Pure White (#FFFFFF) with a 1px solid border (#E2E8F0).
- **Level 2 (Hover/Active States):** A very soft, highly diffused shadow (0px 4px 12px rgba(15, 23, 42, 0.05)) to suggest interactivity without breaking the flat aesthetic.

The interface should feel architectural and "snapped" together rather than floating.

## Shapes

The design system employs a **Soft (Level 1)** roundedness strategy. This choice balances the friendliness of a service-oriented brand with the precision of a professional agency.

- **Standard Components:** 4px (0.25rem) radius (Buttons, Input fields, Small chips).
- **Service Cards:** 8px (0.5rem) radius to create a distinct container feel.
- **Large Sections:** 12px (0.75rem) radius for major dashboard modules or modal windows.

Sharp corners are avoided to prevent the UI from feeling overly aggressive or "dated-corporate," while large radii (pills) are avoided to maintain a sense of structural integrity.

## Components

### Buttons
- **Primary:** Solid Deep Slate (#0F172A) with white text. High-contrast, sharp 4px corners.
- **Secondary:** Transparent background with a 1px Slate border. 
- **Action/Success:** Solid Teal (#0D9488) for final conversion points or "Confirm" actions.

### Service Cards
Cards are the primary vehicle for the "Super-App" feel. They must feature:
- A 1px border (#E2E8F0).
- A subtle icon or illustrative glyph in the top-left using the Secondary color.
- Clear, bold headings followed by concise service descriptions.

### Status Indicators
Status should be indicated using the monospaced Label font (JetBrains Mono) inside a "soft-chip":
- **Pending:** Slate background (10% opacity) with Slate text.
- **Active:** Teal background (10% opacity) with Teal text.
- **Alert:** Red background (10% opacity) with Red text.

### Input Fields
Inputs use a white background with a 1px border. On focus, the border transitions to the Secondary Teal color with a 2px offset "ring" to ensure accessibility and clear focus states. Labels should always be visible above the field, never as placeholder text only.

### Lists & Navigation
Vertical navigation lists should use a "ghost" active state—a light gray-blue background highlight with a 3px vertical accent bar of the Secondary Teal color on the left edge.