---
name: Taki Digital Architecture
colors:
  surface: '#051424'
  surface-dim: '#051424'
  surface-bright: '#2c3a4c'
  surface-container-lowest: '#010f1f'
  surface-container-low: '#0d1c2d'
  surface-container: '#122131'
  surface-container-high: '#1c2b3c'
  surface-container-highest: '#273647'
  on-surface: '#d4e4fa'
  on-surface-variant: '#c6c6cd'
  inverse-surface: '#d4e4fa'
  inverse-on-surface: '#233143'
  outline: '#909097'
  outline-variant: '#45464d'
  surface-tint: '#bec6e0'
  primary: '#bec6e0'
  on-primary: '#283044'
  primary-container: '#0f172a'
  on-primary-container: '#798098'
  inverse-primary: '#565e74'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#251400'
  on-tertiary-container: '#b47300'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#051424'
  on-background: '#d4e4fa'
  surface-variant: '#273647'
typography:
  headline-xl:
    fontFamily: Hanken Grotesk
    fontSize: 60px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 30px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
  container-max: 1280px
---

## Brand & Style
The brand personality is authoritative yet innovative, positioned as a high-end digital architecture firm for complex sectors. The design style follows a **Modern Corporate** aesthetic with **Minimalist** influences, focusing on precision, high-quality typography, and purposeful motion.

The target audience consists of high-stakes decision-makers in government, corporate, and creative sectors. The UI should evoke a sense of structural integrity, technical excellence, and premium service. Visual interest is generated through crisp geometry, sophisticated layering, and a multi-chromatic accent system that breaks the monotony of traditional enterprise software.

## Colors
The color strategy shifts from a monochromatic blue to a deep, multi-dimensional palette. The foundation is built on **Slate (#0F172A)** and **Charcoal (#020617)** to provide a professional, architectural backdrop.

### Functional Accents
Strategic color coding is used to categorize service offerings and provide semantic cues:
- **Emerald (#10B981):** Represents "Government" and "Sustainability." It signals growth, trust, and official capacity.
- **Amber (#F59E0B):** Represents "Career" and "Professional Development." It provides high-contrast warmth and energy.
- **Indigo (#6366F1):** Represents "Creative" and "Digital Strategy." It signals imagination and high-tech sophistication.

Primary CTAs should utilize the **Emerald** accent to contrast against the dark backgrounds, while the **Slate** base ensures a grounded, institutional feel.

## Typography
This design system utilizes **Hanken Grotesk** exclusively to maintain a sharp, contemporary, and technical appearance. 

- **Scale:** Large display sizes use tight tracking and heavy weights to emphasize the "Architecture" aspect of the brand.
- **Hierarchy:** Use uppercase labels for metadata and section headers to provide a structural framework.
- **Legibility:** Body text is set with generous line heights to ensure readability against dark backgrounds, preventing "halpation" or visual vibrating.

## Layout & Spacing
The layout follows a **Fluid Grid** model based on a 12-column structure for desktop and a 4-column structure for mobile. 

- **Vertical Rhythm:** Built on a 4px baseline unit. All component heights and vertical margins must be multiples of 8px.
- **Composition:** Use generous inner-container padding (80px to 120px) to create the "Minimalist" feeling of space and luxury. 
- **Reflow:** On mobile, margins reduce to 16px, and multi-column grids collapse into a single vertical stack. Large headlines should scale down to the defined `headline-lg-mobile` token to maintain visual balance.

## Elevation & Depth
Depth is created through **Tonal Layers** and **Low-Contrast Outlines**. Avoid heavy shadows; instead, use surface color steps to indicate elevation.

- **Level 0 (Base):** #020617 (Background).
- **Level 1 (Card/Surface):** #0F172A (Primary Blue/Slate).
- **Level 2 (Active/Hover):** #1E293B (Surface Lighter).

**Borders:** Use 1px solid borders at 10-15% opacity of the accent color or white to define container edges. This "Ghost Border" technique reinforces the technical, architectural precision of the UI.

## Shapes
The shape language is **Soft (0.25rem)**. This slight rounding takes the edge off the "Brutal" nature of dark backgrounds while maintaining a professional, rigid structure. 

- Use `rounded-lg` (0.5rem) specifically for large cards and modal containers.
- Use `rounded-full` only for status indicators or small icon avatars to provide contrast against the predominantly rectangular layout.

## Components
Consistent component behavior is critical for a "systematic" feel:

- **Buttons:** Primary buttons use the Emerald accent with white text. Secondary buttons are ghost-style with a thin Slate-400 border. Use high-contrast hover states (e.g., background fill becomes 10% lighter).
- **Service Chips:** Categorized by color. Government chips use Emerald backgrounds (low opacity) with Emerald text; Creative uses Indigo; Career uses Amber.
- **Lists:** Use subtle 1px dividers in `#1E293B`. Interactive list items should have a horizontal slide-in effect on hover.
- **Input Fields:** Dark charcoal backgrounds with a 1px Slate border. The border should glow with the Emerald accent color when focused.
- **Cards:** No shadows. Use a 1px border and a slight background color shift to #0F172A. Include an "accent tab" (a 4px vertical line) on the left side of cards to denote their service category (Emerald, Amber, or Indigo).
- **Data Visualizations:** Use the accent palette (Emerald, Amber, Indigo) against the Slate backgrounds to ensure high-contrast readability of charts and technical metrics.